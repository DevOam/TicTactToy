package com.tictactoy

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlin.random.Random as Random1

class MainActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    lateinit var b1: Button
    lateinit var b2: Button
    lateinit var b3: Button
    lateinit var b4: Button
    lateinit var b5: Button
    lateinit var b6: Button
    lateinit var b7: Button
    lateinit var b8: Button
    lateinit var b9: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ini()
    }
    fun buSelect(view: View){
        val buchoise = view as Button
        var cellId = 0
        when(buchoise.id){
            R.id.btn1->cellId=1
            R.id.btn2->cellId=2
            R.id.btn3->cellId=3
            R.id.btn4->cellId=4
            R.id.btn5->cellId=5
            R.id.btn6->cellId=6
            R.id.btn7->cellId=7
            R.id.btn8->cellId=8
            R.id.btn9->cellId=9
        }
        playGame(cellId, buchoise)
        Log.d( "buSelect: ", cellId.toString())
    }
    val player1=ArrayList<Int>()
    val player2=ArrayList<Int>()
    var activePlayer = 1
    fun playGame(cellId:Int, buChoise:Button){
        if (activePlayer==1){
            buChoise.text = "x"
            buChoise.setBackgroundColor(Color.MAGENTA)
            player1.add(cellId)
            activePlayer=2
            autoPlay()
        }else{
            buChoise.text = "o"
            buChoise.setBackgroundColor(Color.BLUE)
            player2.add(cellId)
            activePlayer=1
        }
        buChoise.isEnabled=false
        checkWiner()
    }
    fun checkWiner(){
        var winer = -1
        //row1
        if (player1.contains(1)&&player1.contains(2)&&player1.contains(3)){
            winer=1
        }
        if (player2.contains(1)&&player2.contains(2)&&player2.contains(3)){
            winer=2
        }

        //row2
        if (player1.contains(4)&&player1.contains(5)&&player1.contains(6)){
            winer=1
        }
        if (player2.contains(4)&&player2.contains(5)&&player2.contains(6)){
            winer=2
        }

        //row3
        if (player1.contains(7)&&player1.contains(8)&&player1.contains(9)){
            winer=1
        }
        if (player2.contains(7)&&player2.contains(8)&&player2.contains(9)){
            winer=2
        }
        //col1
        if (player1.contains(1)&&player1.contains(4)&&player1.contains(7)){
            winer=1
        }
        if (player2.contains(1)&&player2.contains(4)&&player2.contains(7)){
            winer=2
        }
        //col2
        if (player1.contains(2)&&player1.contains(5)&&player1.contains(8)){
            winer=1
        }
        if (player2.contains(2)&&player2.contains(5)&&player2.contains(8)){
            winer=2
        }
        //col3
        if (player1.contains(3)&&player1.contains(6)&&player1.contains(9)){
            winer=1
        }
        if (player2.contains(3)&&player2.contains(6)&&player2.contains(9)){
            winer=2
        }
        if (winer!=-1){
            if (winer==1){
                Toast.makeText(this, "player $winer is winer", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this, "player $winer is winer", Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun autoPlay(){
        val emptyCells = ArrayList<Int>()
        for (cellId in 1..9 ){
            if (!(cellId in player1 || cellId in player2)){
                emptyCells.add(cellId)
            }
        }
        val r = Random1
        val randomIndex = r.nextInt(emptyCells.size-0)+0
        val cellIndex = emptyCells[randomIndex]
        var buSelect:Button?
        when(cellIndex){
            1-> buSelect = b1
            2-> buSelect = b2
            3-> buSelect = b3
            4-> buSelect = b4
            5-> buSelect = b5
            6-> buSelect = b6
            7-> buSelect = b7
            8-> buSelect = b8
            9-> buSelect = b9
            else->{
                buSelect=b1
            }
        }
        playGame(cellIndex, buSelect)

    }
    private fun ini(){
    b1 = findViewById(R.id.btn1)
    b2 = findViewById(R.id.btn2)
    b3 = findViewById(R.id.btn3)
    b4 = findViewById(R.id.btn4)
    b5 = findViewById(R.id.btn5)
    b6 = findViewById(R.id.btn6)
    b7 = findViewById(R.id.btn7)
    b8 = findViewById(R.id.btn8)
    b9 = findViewById(R.id.btn9)
    }
}